OcsPanels
=========
Simple and lightweight panel for Reseller SSH based on Webmin API, 100% free.

Features
-------
* ** Deposit System **: Seller only has to deposit, they can create their own SSH account.
* ** Remote Webmin **: enough 1 panel can be used for many VPS.

Requirements
---------

##### Hosting
* PHP version 5.3.4 and above.
* MySQL version 5.0.0 and above.

##### VPS
* Webmin
* Perl XML :: Parser Module (usually installed automatically with webmin)

Installation
------------
* Debian: https://www.hostingtermurah.net/tutorial-install-ocs-panel-pada-vps/
